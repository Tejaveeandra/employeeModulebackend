package com.employee.entity;
 
import java.sql.Timestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
 
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name="sce_emp_bank_detl",schema="sce_employee")
public class BankDetails {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int emp_sal_bank_detl_id;
	
	@Column(name = "acc_type", nullable = false)
	private String acc_type; // Required NOT NULL
	
	private String bank_name;
	private String bank_branch;
	
	@Column(name = "bank_holder_name", nullable = false)
	private String bank_holder_name; // Required NOT NULL
	
	@Column(name = "acc_no", nullable = false)
	private Long acc_no; // int8 in database - bigint
	
	@Column(name = "ifsc_code", nullable = false)
	private String ifsc_code; // Required NOT NULL
	
	@Column(name = "net_payable", nullable = false)
	private float net_payable; // Required NOT NULL - may need to set a default
	
	private String bank_statement_cheque_path;
	
	private int is_active; // Default 1
	
	@ManyToOne
	@JoinColumn(name = "emp_id", nullable = false)
	private Employee emp_id; // Required NOT NULL
	
	@ManyToOne
	@JoinColumn(name = "emp_payment_type_id")
	private EmpPaymentType empPaymentType; // Optional - can be null (maps to emp_payment_type_id column)
	
	// Audit fields - required NOT NULL columns
	@Column(name = "created_by", nullable = false)
	private Integer created_by = 1; // Default to 1 if not provided
	
	@Column(name = "created_date", nullable = false)
	private Timestamp created_date = new Timestamp(System.currentTimeMillis());
	
	@Column(name = "updated_by")
	private Integer updated_by;
	
	@Column(name = "updated_date")
	private Timestamp updated_date;
 
}
 
 