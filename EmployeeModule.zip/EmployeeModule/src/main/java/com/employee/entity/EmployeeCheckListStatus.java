package com.employee.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name="sce_emp_check_list_status",schema="sce_employee")
public class EmployeeCheckListStatus{
	@Id
   @GeneratedValue(strategy = GenerationType.IDENTITY)
	private int emp_check_list_status_id;
	
	private String check_list_status_name;
	private int is_active;
	
	

}
