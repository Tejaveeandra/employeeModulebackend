package com.employee.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "sce_blood_group" , schema = "sce_student")
public class BloodGroup {
	
	
	@Id
	private int blood_group_id;
	private String blood_group_name;
}
