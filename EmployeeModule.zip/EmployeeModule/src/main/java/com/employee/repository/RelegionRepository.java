package com.employee.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.employee.entity.Religion;

public interface RelegionRepository extends JpaRepository<Religion, Integer>{

}
